package educacional;

public class Disciplina {

}
