package oo.encapsulamento.casaA;

public class Ana {

	@SuppressWarnings("unused")
	private String segredo = "...";
	String facoDentroDeCasa = "..."; // default ou pacote
	protected String formaDeFalar = "...";
	public String todosSabem = "...";
}
