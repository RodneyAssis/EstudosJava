package generics;

public class CaixaInt extends Caixa<Integer> {

}
