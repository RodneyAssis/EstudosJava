module app.api {
	exports br.com.cod3r.app;
}