package br.com.cod3r.app;

public interface Calculadora {
	public double soma(double... nums);
	public String getId();
}
