module exericiosfx {
	requires javafx.controls;
	requires javafx.fxml;
	requires org.controlsfx.controls;
	
	opens basico;
	opens layout;
	opens fxml;
	opens calculadora;
}