package br.com.cod3r.cm.excecao;

public class ExplosaoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
