package br.com.teste.exerciciosTeste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciciosTesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
