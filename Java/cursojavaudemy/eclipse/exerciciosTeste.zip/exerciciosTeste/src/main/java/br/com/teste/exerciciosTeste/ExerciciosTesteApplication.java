package br.com.teste.exerciciosTeste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciciosTesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExerciciosTesteApplication.class, args);
	}

}
