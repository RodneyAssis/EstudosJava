package com.FilmesAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmesApiApplication.class, args);
	}

}
